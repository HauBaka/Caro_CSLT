#ifndef _INTROSCREEN_H_
#define _INTROSCREEN_H_
#include "terminalUtils.h"
#include "ModelUtils.h"
#include "Caro_CSLT.h"
#include "FileConfiguration.h"
wstring animatedText(wstring, int&);
void startIntroScreen();
#endif
