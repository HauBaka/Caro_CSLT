﻿#include "Caro_CSLT.h"
FILE* language;
int main()
{
	SetUpWindow();
	startIntroScreen();
	fclose(language);
	return 0;
}
