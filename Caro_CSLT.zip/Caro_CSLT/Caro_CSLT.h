#ifndef _CARO_CSLT_H_
#define _CARO_CSLT_H_
#include "terminalUtils.h"
#include "IntroScreen.h"
#include "ModelUtils.h"
#include <iostream>
using namespace std;
extern FILE* language;
#endif