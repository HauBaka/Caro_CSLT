#ifndef _CONTRIBUTORSSCREEN_H_
#define _CONTRIBUTORSSCREEN_H_
#include "terminalUtils.h"
#include "string.h"
#include "ModelUtils.h"
void ContributorsScreen();
#endif
